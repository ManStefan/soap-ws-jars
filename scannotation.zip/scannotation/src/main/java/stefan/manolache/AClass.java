package stefan.manolache;

/**
 * Created by smanolache on 7/10/2015.
 */
public class AClass {

    @Deprecated
    public void aMethodWithAnnotation(){

    }
}
